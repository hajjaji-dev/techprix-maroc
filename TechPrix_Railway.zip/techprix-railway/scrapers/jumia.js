// TechPrix — Scraper Jumia.ma Électronique & Électroménager
// Usage dans Replit Shell: node scrapers/jumia.js
const https = require('https');
const http  = require('http');

const API_URL     = process.env.REPLIT_URL   || 'http://localhost:3001';
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'techprix-admin-2026';

const CATEGORIES = [
  { url:'https://www.jumia.ma/telephone-tablette/',                   cat:'smartphone',     label:'📱 Téléphones & Tablettes' },
  { url:'https://www.jumia.ma/smartphones/',                          cat:'smartphone',     label:'📱 Smartphones' },
  { url:'https://www.jumia.ma/electronique/',                         cat:'tv-hifi',        label:'📺 TV & High Tech' },
  { url:'https://www.jumia.ma/ordinateurs-accessoires-informatique/', cat:'informatique',   label:'💻 Informatique' },
  { url:'https://www.jumia.ma/mlp-electromenager/',                   cat:'electromenager', label:'🏠 Électroménager' },
  { url:'https://www.jumia.ma/jeux-videos-consoles/',                 cat:'gaming',         label:'🎮 Gaming & Consoles' },
  { url:'https://www.jumia.ma/climatiseurs/',                         cat:'climatisation',  label:'❄️ Climatisation' },
];

const BRANDS = ['Samsung','Apple','Xiaomi','Huawei','Oppo','Vivo','Realme','Nokia','Motorola',
  'Sony','LG','TCL','Hisense','Philips','Panasonic','Sharp','Toshiba',
  'Bosch','Siemens','Whirlpool','Beko','Ariston','Indesit','Electrolux',
  'Tefal','Moulinex','Rowenta','Kenwood','Braun','SEB','Taurus','Midea',
  'HP','Dell','Asus','Acer','Lenovo','MSI','Logitech','Intel','AMD',
  'PlayStation','Xbox','Nintendo','Razer','Honor','Infinix','Tecno','Itel',
  'Haier','Carrier','Daikin','Gree','Chigo','Goldenstar','Daewoo','Brandt',
  'Pacific','Fagor','Continental Edison','Thomson','Telefunken',
  'Gorenje','De Longhi','Krups','Nespresso','Delonghi','Sage'];

function extractBrand(name) {
  const n = name.toLowerCase();
  for (const b of BRANDS) {
    if (n.startsWith(b.toLowerCase()+' ') || n.includes(' '+b.toLowerCase()+' ')) return b;
  }
  return name.split(' ')[0];
}

function parsePrice(str) {
  if (!str) return null;
  const n = parseFloat(str.replace(/[^\d.]/g,''));
  return isNaN(n) || n < 10 || n > 500000 ? null : n;
}

function parseProducts(html, category) {
  const products = [];
  const blocks = html.match(/<article[^>]*class="[^"]*prd[^"]*"[\s\S]*?<\/article>/gi) || [];

  for (const b of blocks) {
    // Nom
    const name = (b.match(/class="[^"]*name[^"]*"[^>]*>([^<]{3,200})<\//) || [])[1]?.trim();
    if (!name) continue;

    // Prix
    const priceRaw = (b.match(/class="[^"]*prc[^"]*"[^>]*>([\d\s,.]+(?:\s*Dhs?)?)/) || [])[1];
    const price = parsePrice(priceRaw);
    if (!price) continue;

    // Ancien prix
    const oldRaw = (b.match(/class="[^"]*old[^"]*"[^>]*>([\d\s,.]+)/) ||
                    b.match(/<del[^>]*>([\d\s,.]+)<\/del>/) || [])[1];
    const oldPrice = parsePrice(oldRaw);

    // Réduction
    const disMatch = b.match(/-\s*(\d+)\s*%/);
    const discount = disMatch ? parseInt(disMatch[1])
      : (oldPrice && oldPrice > price ? Math.round((1-price/oldPrice)*100) : null);

    // Image
    const img = (b.match(/data-src="(https:\/\/ma\.jumia\.is\/[^"?]+)/) ||
                 b.match(/src="(https:\/\/ma\.jumia\.is\/[^"?]+)/) || [])[1] || null;

    // URL
    const link = (b.match(/href="(https:\/\/www\.jumia\.ma\/[^"]+\.html)/) ||
                  b.match(/href="(\/[^"]+\.html)/) || [])[1];
    const productUrl = link ? (link.startsWith('http') ? link : `https://www.jumia.ma${link}`) : null;

    products.push({
      name, price, oldPrice, discount,
      brand: extractBrand(name),
      category,
      imageUrl: img,
      productUrl,
      shop: 'Jumia.ma',
    });
  }
  return products;
}

function fetchHtml(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    const req = mod.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fr-FR,fr;q=0.9',
        'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache',
      },
      timeout: 25000,
    }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchHtml(res.headers.location).then(resolve).catch(reject);
      }
      let d = '';
      res.setEncoding('utf8');
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, html: d }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

function postToApi(products) {
  return new Promise((resolve) => {
    const body = JSON.stringify({ secret: ADMIN_SECRET, products });
    const u = new URL(`${API_URL}/api/admin/import`);
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request({
      hostname: u.hostname,
      port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname,
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: 20000,
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve({ raw: d }); } });
    });
    req.on('error', e => resolve({ error: e.message }));
    req.write(body);
    req.end();
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function main() {
  console.log('\n🔌 TechPrix Morocco — Scraper Jumia.ma');
  console.log('📅 ' + new Date().toLocaleString('fr-MA'));
  console.log('🎯 API: ' + API_URL);
  console.log('━'.repeat(45));

  let grandTotal = 0;

  for (const { url, cat, label } of CATEGORIES) {
    console.log(`\n${label}`);
    let catCount = 0;

    for (let page = 1; page <= 10; page++) {
      const pageUrl = page === 1 ? url : `${url}?page=${page}`;
      try {
        process.stdout.write(`  Page ${page}... `);
        const { status, html } = await fetchHtml(pageUrl);

        if (status !== 200) { console.log(`HTTP ${status} — arrêt`); break; }

        const products = parseProducts(html, cat);
        if (!products.length) { console.log('fin de catalogue'); break; }

        process.stdout.write(`${products.length} produits → `);

        // Sauvegarder dans l'API
        const result = await postToApi(products);
        if (result.saved !== undefined) {
          console.log(`✅ ${result.saved} sauvegardés`);
        } else if (result.error) {
          console.log(`⚠️  ${result.error}`);
        } else {
          console.log('OK');
        }

        catCount += products.length;
        grandTotal += products.length;

        // Délai respectueux
        await sleep(1000 + Math.random() * 800);
      } catch (e) {
        console.log(`❌ ${e.message}`);
        break;
      }
    }
    console.log(`  → Total ${label}: ${catCount} produits`);
    await sleep(2000);
  }

  console.log('\n' + '━'.repeat(45));
  console.log(`✅ Scraping terminé: ${grandTotal} produits traités`);
  console.log('📊 Vérifie: ' + API_URL + '/api/stats');
}

main().catch(e => { console.error('\n❌ Erreur fatale:', e.message); process.exit(1); });
